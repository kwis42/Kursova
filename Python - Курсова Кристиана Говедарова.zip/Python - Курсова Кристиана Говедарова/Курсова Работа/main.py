from animal import *
from cat import *
from dog import *

def main():

  cat1 = Cat("Lea", "Street Extraordinaire", "Female", 4, 5, 20, 100, 30)

  cat2 = Cat("Auti", "British", "Male", 4, 10, 50, 10, 100)

  cat3 = Cat("Cliff", "Street Extraordinaire", "Male", 4, 7, 40,15, 70)

  dog1 = Dog("Jacques", "Jack-Russel", "Male", 4, 80)

  dog2 = Dog("Boris", "Retriever", "Male", 4, 50)

  dog3 = Dog("Kiki", "Pug", "Female", 4, 5)

  cat2.print_info()
  print()
  dog1.print_info()
  
  print()

  print("Cat {0} said: {1}".format(cat2.get_name(), cat2.make_sound()))
  print()
  print("Dog {0} said: {1}".format(dog1.get_name(), dog1.make_sound()))
  print()

  cat1.travel(0.5)
  print('{0} travelled {1} km.'.format(cat1.get_name(),
  cat1.get_distance_travelled()))
  print()

  dog1.eat_cat(cat3)
  dog1.eat_cat(cat1)
  print()

  cat1.print_info()

  cat2.break_object()
  print('Cat {0} broke {1} object'.format(cat2.get_name(), cat2.get_objects_broken()))
  print()

  dog1.pat_dog()
  print("Dog {0} received {1} pats".format(dog1.get_name(), dog1.get_number_of_pats_received()))
  print()

  dog1.print_info()


if __name__== "__main__":
  main()
