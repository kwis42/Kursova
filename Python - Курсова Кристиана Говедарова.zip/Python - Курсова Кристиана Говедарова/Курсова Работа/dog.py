from animal import *

class Dog(Animal):
  def __init__(self, name, species, gender, number_of_legs, speed):

    super().__init__(name, species, gender, number_of_legs, speed)

    self.number_of_pats_received = 0
    self.cats_eaten = 0
    
  def get_number_of_pats_received(self):
    return self.number_of_pats_received

  def pat_dog(self):
    self.number_of_pats_received = self.number_of_pats_received + 1

  def make_sound(self):
    return "björk"

  def eat_cat(self, cat):
    if cat.get_gender() == "Female":
      self.cats_eaten = self.cats_eaten + 1
      print('Cat {0} was eaten, rip X_X'.format(cat.get_name()))
      cat.set_name("Dead")
      cat.set_speed(0)
      cat.set_number_of_legs(0)
      cat.set_species("None")
    else:
      print('{0} was saved by his lack of female parts'.format(cat.get_name()))
  


