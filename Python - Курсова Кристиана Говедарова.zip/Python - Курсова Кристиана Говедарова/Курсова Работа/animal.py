class Animal:

  def __init__(self, name, species, gender, number_of_legs, speed):
      self.set_name(name)
      self.set_species(species)
      self.set_gender(gender)
      self.set_number_of_legs(number_of_legs)
      self.set_speed(speed)
      self.distance_travelled = 0


  def get_name(self):
    return self.name

  def get_species(self):
    return self.species

  def get_gender(self):
    return self.gender
  
  def get_number_of_legs(self):
    return self.number_of_legs

  def get_speed(self):
    return self.speed

  def get_distance_travelled(self):
    return self.distance_travelled

  def set_name(self, name):
    self.name = name

  def set_species(self, species):
    self.species = species

  def set_gender(self, gender):
    self.gender = gender

  def set_number_of_legs(self, number_of_legs):
    self.number_of_legs = number_of_legs

  def set_speed(self, speed):
    self.speed = speed

  def print_info(self):
    print("Name: " + self.get_name())
    print("Species: " + self.get_species())
    print("Gender: " + self.get_gender())
    print("Number of legs: " + str(self.get_number_of_legs()))
    print("Speed: " + str(self.get_speed()) + " km/h")
    print("Distance travelled: " + str(self.get_distance_travelled()) + " km.")

  def compare_animals_speed(self, animal): 
    if self.get_speed() < animal.get_speed():
      print('The first animal is slower than the second animal by {0} km/h'.format(animal.get_speed() - self.get_speed())) 

    elif self.get_speed() > animal.get_speed():
      print('The first animal is faster than the second animal by {0} km/h'.format(self.get_speed() - animal.get_speed()))

    else:
      print('The animals have equal running speeds which is {0} km/h'.format(self.get_speed()))

  def travel(self, hours):
    self.distance_travelled = self.distance_travelled + self.speed * hours

      
  

      