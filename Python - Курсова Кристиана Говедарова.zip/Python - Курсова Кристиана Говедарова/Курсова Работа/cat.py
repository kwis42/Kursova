from animal import *

class Cat(Animal):
  def __init__(self, name, species, gender, number_of_legs, speed, decibels_of_purring, objects_broken, softness_of_paws):

    super().__init__(name, species, gender, number_of_legs, speed)

    self.set_decibels_of_purring(decibels_of_purring)
    self.objects_broken = 0
    self.set_softness_of_paws(softness_of_paws)
  
  def get_decibels_of_purring(self):
    return self.decibels_of_purring

  def get_objects_broken(self):
    return self.objects_broken
    
  def get_softness_of_paws(self):
    return self.softness_of_paws
    
  def set_decibels_of_purring(self, decibels_of_purring):
    self.decibels_of_purring = decibels_of_purring

  def break_object(self):
    self.objects_broken = self.objects_broken + 1


  def set_softness_of_paws(self, softness_of_paws):
    self.softness_of_paws = softness_of_paws

  def make_sound(self):
    return "meow"

  


